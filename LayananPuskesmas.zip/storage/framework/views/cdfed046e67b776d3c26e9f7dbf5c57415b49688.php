

<?php $__env->startSection('title'); ?>
    Tambah Data Poli
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold ">Tambah Data Poli</h6>
    </div>
    <div class="card-body">
        <form action="/poli/add" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleFormControlInput1">Nama Poli</label>
                <input class="form-control" name="nama_poli" type="text">
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput2">Kode Antrian</label>
                <input class="form-control" name="kode_antrian" type="text">
            </div>
            <div class="form-group">
                <a href="/poli" class="btn btn-secondary">kembali</a>
                <input class="btn btn-success" style="background-color: #148414" name="submit" type="submit" value="Tambah Data">
            </div>
        </form>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\HASIL PROJECT\berlangsung\LayananPuskesmas\resources\views/poli/tambah.blade.php ENDPATH**/ ?>