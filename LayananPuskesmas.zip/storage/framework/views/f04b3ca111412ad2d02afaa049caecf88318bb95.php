

<?php $__env->startSection('title'); ?>
    Tambah Data Dokter
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold ">Tambah Data Dokter</h6>
    </div>
    <div class="card-body">
        <form action="/dokter/add" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleFormControlInput1">Nama Lengkap</label>
                <input class="form-control" name="nama" type="text">
            </div>
            <div class="form-group">
                <label for="example-date-input" class="col-form-label">Tanggal Lahir</label>
                <input class="form-control" type="date" name="ttl" id="example-date-input">
            </div>
            <div class="form-group">
                <label for="exampleSelect1">Jenis Kelamin</label>
                <select class="form-control" name="jenis_kelamin" id="exampleSelect1">
                  <option value="Laki-Laki">Laki-Laki</option>
                  <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="exampleTextarea">Alamat</label>
                <textarea class="form-control" name="alamat" id="exampleTextarea" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="exampleSelect1">Poli</label>
                <select class="form-control" name="poli_id" id="exampleSelect1">
                    <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_poli); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <a href="/dokter" class="btn btn-secondary">kembali</a>
                <input class="btn btn-success" style="background-color: #148414" name="submit" type="submit" value="Tambah Data">
            </div>
        </form>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\HASIL PROJECT\berlangsung\LayananPuskesmas\resources\views/dokter/tambah.blade.php ENDPATH**/ ?>